#!/bin/bash
#Class: CIT 470
#Team: Team 2
#Professor: Darci Guriel
#Purpose: This will install and configure NFS.
#Authors: Brandon Hart, Sarah Martin, and Kyle Boger

log=nfslog.log

#HELP COMMAND
if [ "$1" == "-h" ] ; then
    echo "Usage: `basename $0` [Install NFS Server Script. Run ./install-nfs-server.sh to run the script.]"
    exit 0
fi

#Copy /home to /tmp/home
mkdir /tmp/oldhome
cp -R /home/* /tmp/oldhome

#Create new /home
echo -e "nn\np\n\n\nw" | fdisk /dev/sda

partprobe /dev/sda
# Format your new partition as an ext3 file system
mkfs.xfs /dev/sda4
# check the new filesystem
xfs_repair /dev/sda4
# Mount your new partition at a new /home mount point
mount /dev/sda4 /home
#Append to /etc/fstab
echo "/dev/sda4         /home       xfs     defaults      0 0" >> /etc/fstab

#Install nfs-utils
yum install nfs-utils -y

#Exportfs commands
echo "/home	10.0.0.0/8(sync,wdelay,hide,no_subtree_check,sec=sys,rw,secure,root_squash,no_all_squash)" >> /etc/exports
exportfs -a |tee -a $log

#Start services
service nfs start

#Firewall rules
firewall-cmd --zone=public --add-port=2049/tcp --permanent
firewall-cmd --zone=public --add-port=111/tcp --permanent
firewall-cmd --zone=public --add-port=20048/tcp --permanent
firewall-cmd --zone=public --add-port=2049/udp --permanent
firewall-cmd --zone=public --add-port=111/udp --permanent
firewall-cmd --zone=public --add-port=20048/udp --permanent

firewall-cmd --reload
